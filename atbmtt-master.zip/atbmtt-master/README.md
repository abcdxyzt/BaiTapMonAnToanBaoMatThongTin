# atbmtt
Đây là tài liệu học môn an toàn và bảo mật thông tin cho sinh viên ngành <b>Hệ thống thông tin - Trường Đại học Lâm nghiệp.</b>
Các bạn tải về đọc trước nội dung học trước các buổi lên lớp theo hướng dẫn của giảng viên trên lớp sau mỗi buổi học, lập trình trước các thuật toán nếu có thể bằng ngôn ngữ lập trình
Một số phần mềm hỗ trợ làm bài tập:
<br/>
<a href="https://visualstudio.microsoft.com/vs/express">1. Visual Studio Express</a>
<br/>
<a href="https://notepad-plus-plus.org/download/v7.5.8.html">2. Notpad plus plus</a>
<br/><br/>
Các bài tập minh họa trên lớp cũng sẽ được cập nhật tại đây trong mục bàit tập.
Video minh họa các bài tập xem tại đây: <a href="https://www.youtube.com/playlist?list=PL7QnRgf5BcSlGSLQrytwy1ObvgPnCew8g">Video hướng dẫn</a>

